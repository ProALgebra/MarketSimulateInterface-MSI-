from math import ceil


def slippingAverage(db, amount_of_days:int, tikers : [Ticker]):
    needed_month = amount_of_days // 31 + 1
    interesting_dates_over = db.getHistory(needed_month)
    interesting_dates_map = sorted(list(set(interesting_dates_over)))[-amount_of_days:]
    ans = {}
    for tiker in tikers:
        tiker_sum = 0
        for date in interesting_dates_over:
            if tiker in interesting_dates_over[date]:
                tiker_sum += interesting_dates_over[date][tiker].price
            else:
                pass
        ans[tiker] = tiker_sum / amount_of_days

    return ans



class MarketAlgorithm:
    def __init__(self, market : Broker, db : DbBrokerService):
        self.market = market
        self.db = db

    def run(self):
        tikers = ["LKOH", "SBER", "ROSN", "TATN"]
        averages = slippingAverage(self.db, 10, tikers)

        for tiker in tikers:
            tiker_current_cost = self.market.get_share(Ticker(tiker)).price
            if averages[tiker] > tiker_current_cost:
                actions_cover_10_percent = 0.1 * self.market.get_portfolio().cash // tiker_current_cost
                if(actions_cover_10_percent>0):
                    try:
                        self.market.buy(Ticker(tiker), int(actions_cover_10_percent))
                    except:
                        print(f"При попытке купить {actions_cover_10_percent} "
                                         f"{tiker} произошла ошибка: на балансе кошелька недостаточно средств")
                else:
                    self.market.sell(Ticker(tiker), int(ceil(self.market.get_portfolio().shares[Ticker(tiker)] / 2)))
            else:
                actions_cover_10_percent = round(self.market.get_portfolio().shares[Ticker(tiker)])
                self.market.sell(Ticker(tiker), actions_cover_10_percent)


